import { NextRequest, NextResponse } from "next/server"

type GeoCacheEntry = {
  city: string
  cityName: string
  expiresAt: number
}

const geoCache = new Map<string, GeoCacheEntry>()

function isPrivateOrLocalIp(ip: string): boolean {
  const clean = ip.replace(/^::ffff:/i, "").trim()
  if (!clean) return true
  if (
    clean === "::1" ||
    clean === "localhost" ||
    clean.startsWith("127.") ||
    clean.startsWith("10.") ||
    clean.startsWith("192.168.") ||
    clean.startsWith("169.254.") ||
    clean.startsWith("fc") ||
    clean.startsWith("fd") ||
    clean.startsWith("fe80:")
  ) {
    return true
  }
  const m172 = clean.match(/^172\.(\d+)\./)
  if (m172) {
    const oct = Number(m172[1])
    if (oct >= 16 && oct <= 31) return true
  }
  return false
}

function getClientIp(headers: Headers): string {
  const forwarded = headers.get("x-forwarded-for")
  if (forwarded) {
    for (const part of forwarded.split(",")) {
      const candidate = part.trim()
      if (candidate && !isPrivateOrLocalIp(candidate)) {
        return candidate
      }
    }
  }
  for (const h of ["cf-connecting-ip", "x-real-ip"]) {
    const val = (headers.get(h) || "").trim()
    if (val && !isPrivateOrLocalIp(val)) return val
  }
  return ""
}

function isValidCityString(raw: string | null | undefined): boolean {
  if (!raw) return false
  const clean = raw.trim()
  if (clean.length < 2 || clean.length > 60) return false
  if (/^(unknown|none|null|undefined|n\/a|-+|\?+)$/i.test(clean)) return false
  return true
}

async function lookupIpCity(ip: string): Promise<{ city: string; cityName: string } | null> {
  const cached = geoCache.get(ip)
  if (cached && cached.expiresAt > Date.now()) {
    return { city: cached.city, cityName: cached.cityName }
  }

  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), 1600)
  try {
    const res = await fetch(
      `https://ipwho.is/${encodeURIComponent(ip)}?fields=success,country_code,city,region_code`,
      { signal: controller.signal, cache: "no-store" }
    )
    if (res.ok) {
      const data = (await res.json()) as {
        success?: boolean
        country_code?: string
        city?: string
        region_code?: string
      }
      if (data?.success && isValidCityString(data.city)) {
        const cityName = data.city!.trim()
        const formatted =
          data.country_code === "BR" && data.region_code
            ? `${cityName} - ${data.region_code.toUpperCase()}`
            : cityName
        if (geoCache.size > 500) geoCache.clear()
        geoCache.set(ip, {
          city: formatted,
          cityName,
          expiresAt: Date.now() + 60 * 60 * 1000,
        })
        return { city: formatted, cityName }
      }
    }
  } catch {
    // fall through to secondary provider
  } finally {
    clearTimeout(timeout)
  }

  const fallbackController = new AbortController()
  const fallbackTimeout = setTimeout(() => fallbackController.abort(), 1600)
  try {
    const geoRes = await fetch(
      `https://get.geojs.io/v1/ip/geo/${encodeURIComponent(ip)}.json`,
      { signal: fallbackController.signal, cache: "no-store" }
    )
    if (!geoRes.ok) return null
    const geoData = (await geoRes.json()) as {
      country_code?: string
      city?: string
      region?: string
    }
    if (!isValidCityString(geoData?.city)) return null
    const cityName = geoData.city!.trim()
    const formatted =
      geoData.country_code === "BR" && geoData.region
        ? `${cityName} - ${geoData.region}`
        : cityName
    if (geoCache.size > 500) geoCache.clear()
    geoCache.set(ip, {
      city: formatted,
      cityName,
      expiresAt: Date.now() + 60 * 60 * 1000,
    })
    return { city: formatted, cityName }
  } catch {
    return null
  } finally {
    clearTimeout(fallbackTimeout)
  }
}

export async function GET(req: NextRequest) {
  const headers = req.headers
  const region = (
    headers.get("x-vercel-ip-country-region") ||
    headers.get("cf-region-code") ||
    headers.get("x-appengine-region") ||
    ""
  )
    .trim()
    .toUpperCase()

  const rawCity = (
    headers.get("x-vercel-ip-city") ||
    headers.get("cf-ipcity") ||
    headers.get("x-appengine-city") ||
    ""
  ).trim()

  if (isValidCityString(rawCity)) {
    let decodedCity = rawCity
    try {
      decodedCity = decodeURIComponent(rawCity)
    } catch {
      decodedCity = rawCity
    }
    if (isValidCityString(decodedCity)) {
      const cityLabel = region ? `${decodedCity} - ${region}` : decodedCity
      return NextResponse.json({
        city: cityLabel,
        cityName: decodedCity,
        detected: true,
        source: "header",
        accuracy: "city",
      })
    }
  }

  const clientIp = getClientIp(headers)
  if (clientIp) {
    const ipResult = await lookupIpCity(clientIp)
    if (ipResult) {
      return NextResponse.json({
        ...ipResult,
        detected: true,
        source: "ip",
        accuracy: "ip_estimate",
      })
    }
  }

  return NextResponse.json({
    city: "São Paulo - SP",
    cityName: null,
    detected: false,
    source: "none",
    accuracy: "none",
  })
}
