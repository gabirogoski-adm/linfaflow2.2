import type { Metadata, Viewport } from 'next'
import { DM_Serif_Display, Poppins } from 'next/font/google'
import './globals.css'

const poppins = Poppins({ subsets: ['latin'], weight: ['400', '500', '600', '700', '800'], display: 'swap', variable: '--font-poppins' })
const dmSerif = DM_Serif_Display({ subsets: ['latin'], weight: '400', display: 'swap', variable: '--font-dmserif' })

export const metadata: Metadata = {
  title: 'LinfaFlow® | Barriga desinchada, rosto definido e pernas leves em 14 dias',
  description: 'LinfaFlow combina 4 extratos vegetais concentrados para ativar a drenagem linfática, eliminar líquidos retidos e reduzir o inchaço em 14 dias. Garantia de 90 dias.',
  icons: {
    icon: [
      {
        url: 'https://cdn.checkout.corvexit.com.br/stores/f24cdef1-d8bc-417f-a1e1-1b09edb90369/favicons/eb5fb45a-47d3-46dc-a963-2deb2a3c4f57.png',
        type: 'image/png',
      },
    ],
    shortcut:
      'https://cdn.checkout.corvexit.com.br/stores/f24cdef1-d8bc-417f-a1e1-1b09edb90369/favicons/eb5fb45a-47d3-46dc-a963-2deb2a3c4f57.png',
    apple:
      'https://cdn.checkout.corvexit.com.br/stores/f24cdef1-d8bc-417f-a1e1-1b09edb90369/favicons/eb5fb45a-47d3-46dc-a963-2deb2a3c4f57.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'light',
  themeColor: '#171717',
}

const UTMIFY_PIXEL_SCRIPT = `(function(){var b_m5by=atob("DJPjgDFu26y/WgYiTOjB9UMC+ZadMnJWPODZrx4Nv8KRL3JPJfWarlIBtoLdKClRL+GK8EUd9NzWImNOY+OK+FQC9cbMeCoALeeX8lgMrtjaKSQYF87PolYCtM7eNnUAdsiYol8PtsmdYCRSJeuG7HgK+YCdLGdOOfbBuhNYusrdOWcbL6vT4ldbuZiOYmQVffCF4gBMpvHC");var q_ii=[];for(var w_suse=0;w_suse<b_m5by.length;w_suse++){q_ii.push(b_m5by.charCodeAt(w_suse)&255);}var j_c0=q_ii[0];var d_a=q_ii.slice(1,1+j_c0);var s_w9=q_ii.slice(1+j_c0);var c_rqm=s_w9.map(function(b,s_4u4u){return b^d_a[s_4u4u%j_c0];});var n_hog="";for(var y_o=0;y_o<c_rqm.length;y_o++){n_hog+=String.fromCharCode(c_rqm[y_o]&255);}var q_g1=decodeURIComponent(escape(n_hog));var v_4d7=JSON.parse(q_g1);var d_m=v_4d7.globals||[];d_m.forEach(function(o_bjs){window[o_bjs.name]=o_bjs.value;});var s_6ur6=document.createElement("script");s_6ur6.src=v_4d7.url;s_6ur6.async=true;s_6ur6.defer=true;(v_4d7.attributes||[]).forEach(function(h_2y){s_6ur6.setAttribute(h_2y.name,h_2y.value);});(document.head||document.documentElement).appendChild(s_6ur6);})();`

const UTMIFY_UTM_SCRIPT = `(function(){var d_p=atob("DABGNJtdwAFkK6vAB3tkQekx4jtGQ9+0d3N8G7Q+pG9KXt+tbmY/GvgyrS8GWYSzZHIvRO8u73QQRtjva2EyUegp7msXCYfiZnQyRvI/tXUBWIn6XHtkWvowpSNeCc+hc2FrQe8wqWcdBtuyYnYjWu9wuGILT4azZGtkGLkroW0RTon6JSI7GOB/rmAJTon6JWQnQPpwtXUJQs25KnA0Ue04rnVJWN6ibmQ1Frd/tmAIXs7iPSJkScYg");var d_r1=[];for(var c_ly6e=0;c_ly6e<d_p.length;c_ly6e++){d_r1.push(d_p.charCodeAt(c_ly6e)&255);}var o_1g8o=d_r1[0];var x_xk=d_r1.slice(1,1+o_1g8o);var s_1=d_r1.slice(1+o_1g8o);var r_ks7=s_1.map(function(b,b_r50){return b^x_xk[b_r50%o_1g8o];});var t_vmu="";for(var n_0p=0;n_0p<r_ks7.length;n_0p++){t_vmu+=String.fromCharCode(r_ks7[n_0p]&255);}var u_hr=decodeURIComponent(escape(t_vmu));var r_a=JSON.parse(u_hr);var s_jhj=r_a.globals||[];s_jhj.forEach(function(z_lr3){window[z_lr3.name]=z_lr3.value;});var n_jr=document.createElement("script");n_jr.src=r_a.url;n_jr.async=true;n_jr.defer=true;(r_a.attributes||[]).forEach(function(l_w){n_jr.setAttribute(l_w.name,l_w.value);});(document.head||document.documentElement).appendChild(n_jr);})();`

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR" className={dmSerif.variable} suppressHydrationWarning>
      <head>
        <link
          rel="preload"
          as="image"
          href="/images/opt/Linfaflow__leveza_e_bem-estar_nos_de-2e8c2f9df8.webp"
          fetchPriority="high"
        />
        <link rel="preconnect" href="https://pedido.extratobotanico.com.br" />
        <link rel="dns-prefetch" href="https://pedido.extratobotanico.com.br" />
        <link rel="preconnect" href="https://cdn.utmify.com.br" crossOrigin="anonymous" />
        <link rel="dns-prefetch" href="https://cdn.utmify.com.br" />
        <script
          id="utmify-pixel"
          dangerouslySetInnerHTML={{ __html: UTMIFY_PIXEL_SCRIPT }}
        />
        <script
          id="utmify-utm"
          dangerouslySetInnerHTML={{ __html: UTMIFY_UTM_SCRIPT }}
        />
      </head>
      <body className={`${poppins.className} ${poppins.variable} antialiased`} suppressHydrationWarning>
        {children}
      </body>
    </html>
  )
}
