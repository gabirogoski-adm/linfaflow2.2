const LEAD_NAME_KEYS = [
  "nome_completo",
  "full_name",
  "fullname",
  "customer_name",
  "lead_name",
  "buyer_name",
  "recipient_name",
  "subscriber_name",
  "user_name",
  "visitor_name",
  "utm_name",
  "utm_lead",
  "nome",
  "name",
  "lead",
  "cliente",
  "paciente",
  "first_name",
  "fname",
  "nm",
]

const LEAD_NAME_STORAGE_KEYS = [
  "linfaflow_lead_name",
  "lead_name",
  "customer_name",
  "nome_completo",
  "user_name",
  "leadName",
  "customerName",
  "visitor_name",
  "buyer_name",
  "nome",
  "name",
  "first_name",
  "fname",
]

const LEAD_CITY_KEYS = [
  "cidade",
  "city",
  "utm_city",
  "municipio",
  "local",
  "location",
  "geo_city",
  "customer_city",
  "lead_city",
]

const LEAD_CITY_STORAGE_KEYS = [
  "linfaflow_lead_city",
  "lead_city",
  "visitor_city",
  "customer_city",
  "leadCity",
  "cidade",
  "city",
]

const JSON_PROFILE_KEYS = [
  "linfaflow_lead",
  "lead",
  "customer",
  "user",
  "user_data",
  "userData",
  "customerData",
  "leadData",
  "checkout_lead",
  "checkoutData",
  "visitor",
  "utmify_lead",
  "utmify",
]

const GLOBAL_OBJECT_KEYS = [
  "__LEAD__",
  "__LEAD_DATA__",
  "lead",
  "leadData",
  "customer",
  "customerData",
  "user",
  "userData",
  "visitor",
  "checkoutData",
  "utmify",
  "utmifyData",
  "pixelData",
]

const GLOBAL_STRING_NAME_KEYS = [
  "__LEAD_NAME__",
  "leadName",
  "lead_name",
  "customerName",
  "customer_name",
  "userName",
  "user_name",
  "visitorName",
  "visitor_name",
]

const GLOBAL_STRING_CITY_KEYS = [
  "__LEAD_CITY__",
  "leadCity",
  "lead_city",
  "customerCity",
  "customer_city",
  "visitorCity",
  "visitor_city",
]

const LOWERCASE_PARTICLES = new Set(["de", "da", "do", "das", "dos", "e"])

const INVALID_VALUE_REGEX =
  /^(null|undefined|none|false|true|nan|teste|test|lead|cliente|paciente|visitor|visitante|unknown|anonymous|anon|n\/a|-+)$/i

function decodeSafe(value: string): string {
  try {
    return decodeURIComponent(value)
  } catch {
    return value
  }
}

export function sanitizeLeadName(raw: string | null | undefined): string | null {
  if (!raw || typeof raw !== "string") return null
  const cleaned = decodeSafe(raw)
    .replace(/\+/g, " ")
    .replace(/[\r\n\t]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()

  if (!cleaned || cleaned.length < 2 || cleaned.length > 72) return null
  if (/^[0-9\W_]+$/.test(cleaned)) return null
  if (/[{}[\]<>%$@]|https?:\/\//i.test(cleaned)) return null
  if (INVALID_VALUE_REGEX.test(cleaned)) return null

  const words = cleaned
    .split(" ")
    .filter(Boolean)
    .slice(0, 6)
    .map((part, idx) => {
      const low = part.toLowerCase()
      if (idx > 0 && LOWERCASE_PARTICLES.has(low)) return low
      return low.charAt(0).toUpperCase() + low.slice(1)
    })

  const normalized = words.join(" ")
  if (normalized.length < 2 || INVALID_VALUE_REGEX.test(normalized)) return null
  return normalized
}

export function sanitizeCityName(raw: string | null | undefined): string | null {
  if (!raw || typeof raw !== "string") return null
  const cleaned = decodeSafe(raw)
    .replace(/\+/g, " ")
    .replace(/[\r\n\t]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()

  if (!cleaned || cleaned.length < 2 || cleaned.length > 42) return null
  if (/^[0-9\W_]+$/.test(cleaned)) return null
  if (/[{}[\]<>%$@]|https?:\/\//i.test(cleaned)) return null
  if (INVALID_VALUE_REGEX.test(cleaned)) return null

  // Strip optional " - UF" suffix for the inline "Cidade, 18 de novembro de 2026." line
  const withoutUf = cleaned.replace(/\s*[-/,]\s*[A-Z]{2}$/i, "").trim()
  if (!withoutUf || withoutUf.length < 2) return null

  return withoutUf
    .split(" ")
    .filter(Boolean)
    .map((part, idx) => {
      const low = part.toLowerCase()
      if (idx > 0 && LOWERCASE_PARTICLES.has(low)) return low
      return low.charAt(0).toUpperCase() + low.slice(1)
    })
    .join(" ")
}

function getAllUrlParams(): URLSearchParams {
  const merged = new URLSearchParams(window.location.search)
  const hash = window.location.hash
  if (hash && hash.includes("=")) {
    const queryPart = hash.includes("?")
      ? hash.slice(hash.indexOf("?") + 1)
      : hash.replace(/^#/, "")
    try {
      new URLSearchParams(queryPart).forEach((val, key) => {
        if (!merged.has(key)) merged.set(key, val)
      })
    } catch {
      // ignore malformed hash
    }
  }
  return merged
}

function getCookieMap(): Map<string, string> {
  const map = new Map<string, string>()
  try {
    const raw = document.cookie || ""
    for (const chunk of raw.split(";")) {
      const eq = chunk.indexOf("=")
      if (eq <= 0) continue
      const key = chunk.slice(0, eq).trim()
      const val = chunk.slice(eq + 1).trim()
      if (key && val) map.set(key, decodeSafe(val))
    }
  } catch {
    // ignore cookie errors
  }
  return map
}

function extractFieldFromObject(
  obj: unknown,
  fields: string[],
  sanitizer: (val: string | null | undefined) => string | null,
  includeCombinedFirstLast: boolean,
  depth = 0
): string | null {
  if (!obj || typeof obj !== "object" || depth > 3) return null
  const record = obj as Record<string, unknown>

  if (includeCombinedFirstLast && typeof record.first_name === "string") {
    const last =
      typeof record.last_name === "string"
        ? record.last_name
        : typeof record.lname === "string"
          ? record.lname
          : ""
    const combined = last ? `${record.first_name} ${last}` : record.first_name
    const clean = sanitizer(combined)
    if (clean) return clean
  }

  for (const field of fields) {
    const val = record[field]
    if (typeof val === "string") {
      const clean = sanitizer(val)
      if (clean) return clean
    }
  }

  for (const nestedKey of ["user_data", "userData", "customer", "lead", "address", "data", "buyer"]) {
    if (record[nestedKey] && typeof record[nestedKey] === "object") {
      const nested = extractFieldFromObject(
        record[nestedKey],
        fields,
        sanitizer,
        includeCombinedFirstLast,
        depth + 1
      )
      if (nested) return nested
    }
  }

  return null
}

function tryExtractFromJsonString(
  raw: string | null | undefined,
  fields: string[],
  sanitizer: (val: string | null | undefined) => string | null,
  includeCombinedFirstLast = false
): string | null {
  if (!raw) return null
  const trimmed = raw.trim()
  if (!trimmed.startsWith("{")) return null
  try {
    const parsed = JSON.parse(trimmed)
    return extractFieldFromObject(parsed, fields, sanitizer, includeCombinedFirstLast)
  } catch {
    return null
  }
}

function safeStorageGet(storage: Storage | undefined, key: string): string | null {
  try {
    return storage?.getItem(key) ?? null
  } catch {
    return null
  }
}

function safeStorageSet(key: string, value: string) {
  try {
    window.localStorage?.setItem(key, value)
    window.sessionStorage?.setItem(key, value)
  } catch {
    // ignore storage quota errors
  }
}

function inspectAllStorageForField(
  storage: Storage | undefined,
  explicitKeys: string[],
  fields: string[],
  sanitizer: (val: string | null | undefined) => string | null,
  includeCombinedFirstLast: boolean
): string | null {
  if (!storage) return null

  for (const key of explicitKeys) {
    const candidate = sanitizer(safeStorageGet(storage, key))
    if (candidate) return candidate
  }

  for (const jsonKey of JSON_PROFILE_KEYS) {
    const fromJson = tryExtractFromJsonString(
      safeStorageGet(storage, jsonKey),
      fields,
      sanitizer,
      includeCombinedFirstLast
    )
    if (fromJson) return fromJson
  }

  try {
    const len = Math.min(storage.length, 80)
    for (let i = 0; i < len; i++) {
      const key = storage.key(i)
      if (!key) continue
      const val = safeStorageGet(storage, key)
      if (!val) continue

      const lowerKey = key.toLowerCase()
      if (val.trim().startsWith("{")) {
        const fromJson = tryExtractFromJsonString(
          val,
          fields,
          sanitizer,
          includeCombinedFirstLast
        )
        if (fromJson) return fromJson
      } else if (
        /(lead|utm|customer|user|buyer|client|visitor|form|pixel)/.test(lowerKey) &&
        explicitKeys.some((k) => lowerKey.includes(k.toLowerCase()))
      ) {
        const clean = sanitizer(val)
        if (clean) return clean
      }
    }
  } catch {
    // ignore storage iteration restrictions
  }

  return null
}

function inspectWindowGlobals(
  stringKeys: string[],
  fields: string[],
  sanitizer: (val: string | null | undefined) => string | null,
  includeCombinedFirstLast: boolean
): string | null {
  const win = window as unknown as Record<string, unknown>

  for (const gKey of stringKeys) {
    if (typeof win[gKey] === "string") {
      const clean = sanitizer(win[gKey] as string)
      if (clean) return clean
    }
  }

  for (const objKey of GLOBAL_OBJECT_KEYS) {
    const candidateObj = win[objKey]
    if (candidateObj && typeof candidateObj === "object") {
      const clean = extractFieldFromObject(
        candidateObj,
        fields,
        sanitizer,
        includeCombinedFirstLast
      )
      if (clean) return clean
    }
  }

  if (Array.isArray(win.dataLayer)) {
    for (let i = win.dataLayer.length - 1; i >= 0; i--) {
      const entry = win.dataLayer[i]
      if (entry && typeof entry === "object") {
        const clean = extractFieldFromObject(
          entry,
          fields,
          sanitizer,
          includeCombinedFirstLast
        )
        if (clean) return clean
      }
    }
  }

  return null
}

export function detectLeadNameFromClient(): string | null {
  if (typeof window === "undefined") return null

  const params = getAllUrlParams()

  // 1. Combined first_name + last_name in URL
  const firstName = sanitizeLeadName(params.get("first_name") || params.get("fname"))
  const lastName = sanitizeLeadName(params.get("last_name") || params.get("lname"))
  if (firstName && lastName) {
    const combined = sanitizeLeadName(`${firstName} ${lastName}`)
    if (combined) {
      safeStorageSet("linfaflow_lead_name", combined)
      return combined
    }
  }

  // 2. Standard name query parameters
  for (const key of LEAD_NAME_KEYS) {
    const candidate = sanitizeLeadName(params.get(key))
    if (candidate) {
      safeStorageSet("linfaflow_lead_name", candidate)
      return candidate
    }
  }

  // 3. Window globals (including async tracking & dataLayer objects)
  const fromGlobals = inspectWindowGlobals(
    GLOBAL_STRING_NAME_KEYS,
    LEAD_NAME_KEYS,
    sanitizeLeadName,
    true
  )
  if (fromGlobals) {
    safeStorageSet("linfaflow_lead_name", fromGlobals)
    return fromGlobals
  }

  // 4. Cookies (direct & JSON values)
  const cookies = getCookieMap()
  for (const key of LEAD_NAME_KEYS) {
    const candidate = sanitizeLeadName(cookies.get(key))
    if (candidate) return candidate
  }
  for (const [, val] of cookies.entries()) {
    const fromJson = tryExtractFromJsonString(val, LEAD_NAME_KEYS, sanitizeLeadName, true)
    if (fromJson) return fromJson
  }

  // 5. localStorage & sessionStorage (all explicit & JSON keys)
  for (const storage of [window.localStorage, window.sessionStorage]) {
    const found = inspectAllStorageForField(
      storage,
      LEAD_NAME_STORAGE_KEYS,
      LEAD_NAME_KEYS,
      sanitizeLeadName,
      true
    )
    if (found) return found
  }

  return null
}

export function detectLeadCityFromClient(): string | null {
  if (typeof window === "undefined") return null

  const params = getAllUrlParams()
  for (const key of LEAD_CITY_KEYS) {
    const candidate = sanitizeCityName(params.get(key))
    if (candidate) {
      safeStorageSet("linfaflow_lead_city", candidate)
      return candidate
    }
  }

  const fromGlobals = inspectWindowGlobals(
    GLOBAL_STRING_CITY_KEYS,
    LEAD_CITY_KEYS,
    sanitizeCityName,
    false
  )
  if (fromGlobals) {
    safeStorageSet("linfaflow_lead_city", fromGlobals)
    return fromGlobals
  }

  const cookies = getCookieMap()
  for (const key of LEAD_CITY_KEYS) {
    const candidate = sanitizeCityName(cookies.get(key))
    if (candidate) return candidate
  }
  for (const [, val] of cookies.entries()) {
    const fromJson = tryExtractFromJsonString(val, LEAD_CITY_KEYS, sanitizeCityName, false)
    if (fromJson) return fromJson
  }

  for (const storage of [window.localStorage, window.sessionStorage]) {
    const found = inspectAllStorageForField(
      storage,
      LEAD_CITY_STORAGE_KEYS,
      LEAD_CITY_KEYS,
      sanitizeCityName,
      false
    )
    if (found) return found
  }

  return null
}

export function detectLeadPersonalizationFromClient(): {
  name: string | null
  city: string | null
} {
  return {
    name: detectLeadNameFromClient(),
    city: detectLeadCityFromClient(),
  }
}

export function subscribeToPersonalizationUpdates(
  onUpdate: (data: { name: string | null; city: string | null }) => void
): () => void {
  if (typeof window === "undefined") return () => {}

  let lastName: string | null | undefined = undefined
  let lastCity: string | null | undefined = undefined
  let disposed = false

  const emitIfChanged = () => {
    if (disposed) return
    const next = detectLeadPersonalizationFromClient()
    if (next.name !== lastName || next.city !== lastCity) {
      lastName = next.name
      lastCity = next.city
      onUpdate(next)
    }
  }

  emitIfChanged()

  const onScriptOrWindowEvent = () => emitIfChanged()
  const onCaptureLoad = (ev: Event) => {
    const target = ev.target
    if (target instanceof HTMLScriptElement) {
      emitIfChanged()
      window.setTimeout(emitIfChanged, 120)
    }
  }

  window.addEventListener("load", onScriptOrWindowEvent)
  window.addEventListener("storage", onScriptOrWindowEvent)
  window.addEventListener("popstate", onScriptOrWindowEvent)
  window.addEventListener("hashchange", onScriptOrWindowEvent)
  window.addEventListener("focus", onScriptOrWindowEvent)
  document.addEventListener("load", onCaptureLoad, true)

  const onVisibilityChange = () => {
    if (document.visibilityState === "visible") emitIfChanged()
  }
  document.addEventListener("visibilitychange", onVisibilityChange)

  // Attach load listeners to already-injected async scripts (such as UTMify)
  const watchedScripts = new WeakSet<HTMLScriptElement>()
  const attachScriptWatch = (scriptEl: HTMLScriptElement) => {
    if (watchedScripts.has(scriptEl)) return
    watchedScripts.add(scriptEl)
    scriptEl.addEventListener("load", onScriptOrWindowEvent)
  }

  document.querySelectorAll("script").forEach((s) => attachScriptWatch(s))

  let observer: MutationObserver | null = null
  if (typeof MutationObserver !== "undefined" && document.head) {
    observer = new MutationObserver((mutations) => {
      for (const m of mutations) {
        m.addedNodes.forEach((node) => {
          if (node instanceof HTMLScriptElement) {
            attachScriptWatch(node)
          }
        })
      }
      emitIfChanged()
    })
    observer.observe(document.head, { childList: true, subtree: true })
  }

  // Re-check periodically during initial page settle in case async scripts fetch/write storage
  const checkpoints = [150, 500, 1200, 2500, 4500]
  const timers = checkpoints.map((ms) => window.setTimeout(emitIfChanged, ms))

  return () => {
    disposed = true
    window.removeEventListener("load", onScriptOrWindowEvent)
    window.removeEventListener("storage", onScriptOrWindowEvent)
    window.removeEventListener("popstate", onScriptOrWindowEvent)
    window.removeEventListener("hashchange", onScriptOrWindowEvent)
    window.removeEventListener("focus", onScriptOrWindowEvent)
    document.removeEventListener("load", onCaptureLoad, true)
    document.removeEventListener("visibilitychange", onVisibilityChange)
    observer?.disconnect()
    timers.forEach((id) => window.clearTimeout(id))
  }
}
